function toggleMenu(){
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('mobileBackdrop');
  if(sidebar){ sidebar.classList.toggle('open'); }
  if(backdrop){ backdrop.classList.toggle('show'); }
}
function closeMenu(){
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('mobileBackdrop');
  if(sidebar){ sidebar.classList.remove('open'); }
  if(backdrop){ backdrop.classList.remove('show'); }
}
document.addEventListener('DOMContentLoaded', function(){
  const textarea = document.querySelector('textarea[name="descricao"]');
  const counter = document.getElementById('charCount');
  if(textarea && counter){
    const update = () => counter.textContent = textarea.value.length;
    textarea.addEventListener('input', update);
    update();
  }
});
